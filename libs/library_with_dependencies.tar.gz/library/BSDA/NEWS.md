# BSDA 1.2.2

* Updated `t.test()` and `wilcox.test()` examples when using `paired = TRUE`. 

# BSDA 1.2.1

* Updated `z.test()` to function with `NA`s.



